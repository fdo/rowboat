from django.shortcuts import render, HttpResponse
from todo.models import Weight

#from django.core.context_processors import csrf
#from django.shortcuts import render, render_to_response, get_object_or_404, HttpResponse
from datetime import datetime
from django import forms
#from rowboat.todo.models import Weight
from django.template import Context, Template, RequestContext
from rowboat.settings import STATIC_WEBPAGE_ROOT
from rowboat.settings import STATIC_URL


# what file is this?


def what(request):
    response = HttpResponse()
    response.write("<body><html>\n")
    response.write("<title>accessing a database for fun and profit, well for fun</title>\n")
    response.write("<center><H4>no static pages here<br> goto www.gorchs.net for static pages<br>Django and SQLite make this too easy...</H4></center><HR>\n")
    link = "<a href=\"/fitness/weight/\">\n"
    response.write("<li>%srecordings of my weight</a></li>\n" % link)
    link = "<a href=\"/fitness/running/\">\n"
    response.write("<li>%sskimpy running diary</a></li>\n" % link)
    link = "<a href=\"/fitness/reps/\">\n"
    response.write("<li>%sexercise</a></li>\n" % link)
    link = "<a href=\"/fitness/reps/chinups/\">\n"
    response.write("<li>%schinups</a></li>\n" % link)
    link = "<a href=\"/fitness/reps/pushups/\">\n"
    response.write("<li>%spushups</a></li>\n" % link)
    link = "<a href=\"/people/\">\n"
    response.write("<li>%slist of people</a></li>\n" % link)
    link = "<a href=\"/police/\">\n"
    response.write("<li>%sHelp Police!</li>\n" % link)
    response.write("<p><a href=\"https://github.com/fdo/mydjango\">the code for this website</a>")
    response.write("</body></html>\n")
    return response

def weight(request):
    response = HttpResponse()
    response.write("<body><html>\n")
    response.write("<title>archive of weightwatching, do not laugh!</title>\n")
    wlist = Weight.objects.all()
    for p in reversed(wlist):
#    for p in wlist:
        junk = "I weighed %s on %s" % (p.damage,p.timeenter)
        response.write("%s--%s.<br>" % (junk,p.data))
    response.write("</body></html>")
    return response

def oldaddweight(request):
    response = HttpResponse()
    response.write("<body><html>\n")
    response.write("<title>add todays weight into the database</title>\n")
    response.write("<h1>WORKIN PROGRESS")
    wlist = Weight.objects.all()
    for p in reversed(wlist):
#    for p in wlist:
        junk = "I weighed %s on %s" % (p.damage,p.timeenter)
        response.write("%s--%s.<br>" % (junk,p.data))
    response.write("WORKIN PROGRESS")
    response.write("</body></html>")
    return response

class WeightForm(forms.Form):
    data = forms.CharField(max_length=200)
    damage = forms.DecimalField(max_digits=4, decimal_places=1)

def addweight(request):
    rForm = WeightForm()
    if request.method == 'GET':
        message = 'Please add your observations and your poundage to our database.'
    if request.method == 'POST':
        if request.POST['submit'] == 'Add':
            rf = WeightForm(request.POST.copy())
            if rf.is_valid():
                try:
                    report=Weight()
                    report.title = rf.cleaned_data['data']
                    report.details = rf.cleaned_data['damage']
                    report.timeenter = datetime.now()
                    report.save()
                    goofynumber = report.id + 474244
                    #static webpage root should be something like c://documents//environments//project02//rowboat//
                    #static URL (for now) should be http://localhost// later maybe http://18.216.126.118//
                    newfile = STATIC_WEBPAGE_ROOT + 'weight/'  + str(report.id) + '.html'
                    newurl = STATIC_URL + 'weight/' + str(report.id) + '.html'
                    message = 'Thanks! You created a webpage at %s' % newurl
                    f = open(newfile,'w')
                    f.write("<html><body><center><FONT color=#000090 size=6> %s </FONT><FONT color=#000090 size=2> by </FONT>\n" % report.title)
                    f.write("<FONT color=#000090 size=4> %s </FONT></center><HR>\n" % report.author)
                    f.write("<FONT color=#000090 size=3><pre> %s\n " % report.details)
                    #f.write("<br><FONT color=#002080 size=2> static web page root is %s " % newfile)
                    f.close()
                except:
                    message = 'Database error %s' % rf.is_valid()
            else:
                message = 'Invalid data in Form'
    return render(request, 'addweight.html', {'rForm':rForm, 'message':message})
