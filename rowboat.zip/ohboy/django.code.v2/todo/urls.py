# urls.py
from django.urls import path

from . import views

urlpatterns = [
    url('^$/') 
    path('', views.what, name='what'),
    path('weight/', views.weight),
    path('addweight/', views.addweight),
]