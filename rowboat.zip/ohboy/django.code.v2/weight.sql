CREATE TABLE IF NOT EXISTS "todo_weight" 
    ( "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
      "data" varchar(200) NOT NULL,
      "damage" decimal NOT NULL,
      "timeenter" datetime NOT NULL
    )
;