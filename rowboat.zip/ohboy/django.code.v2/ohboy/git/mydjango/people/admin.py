from mydjango.people.models import Person
from django.contrib import admin

admin.site.register(Person)	 
