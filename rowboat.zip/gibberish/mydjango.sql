BEGIN;
--
-- Create model PoliceReport
--
CREATE TABLE "todo_policereport" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "offense" varchar(60) NOT NULL, "license_number" varchar(10) NOT NULL, "Details" text NOT NULL, "timeenter" datetime NOT NULL);
--
-- Create model Reps
--
CREATE TABLE "todo_reps" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "exercise" varchar(60) NOT NULL, "reps" integer NOT NULL, "more" varchar(200) NOT NULL, "timeenter" datetime NOT NULL);
--
-- Create model Running
--
CREATE TABLE "todo_running" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "data" varchar(200) NOT NULL, "minutes" integer NOT NULL, "timeenter" datetime NOT NULL);
--
-- Create model Weight
--
CREATE TABLE "todo_weight" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "data" varchar(200) NOT NULL, "damage" decimal NOT NULL, "timeenter" datetime NOT NULL);
COMMIT;
