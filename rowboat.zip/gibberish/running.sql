CREATE TABLE IF NOT EXISTS "todo_running" 
    (
      "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
      "data" varchar(200) NOT NULL,
      "minutes" integer NOT NULL,
      "timeenter" datetime NOT NULL
    )
;